<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Yönetim Paneli</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            background-color: blue;
        }

        h1 {
            text-align: center;
        }

        .menu {
            width: 300px;
            height: 100%;
            position: fixed; /* Menünün sabit bir konumda durmasını sağlar */
            top: 0;
            left: 0;
            background-color: black;
            color: #fff;
            padding: 20px;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        li {
            margin: 10px 0;
        }

        button {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: left;
        }

        button:hover {
            background-color: #2980b9;
        }
        #meg_an {
            display: block; /* Resmi blok öğe yap ve bu, dikey ortalamayı etkinleştirir */
          margin: 0 auto; 
          margin-left: 800px;
        }
        #anamenu{
            background-color: red;
        }
        .kare{
    width: 900px; /* Kare genişliği */
    height: 600px; /* Kare yüksekliği */
    background-color: gray; /* Kare arka plan rengi */
    margin: 0 auto; /* Kareyi yatayda ortala */
    margin-top: 30px; 
    margin-right: 150px;
        }
     #hakkında{
        text-align: center;
     }   
    </style>
</head>
<body>
    <div id="output"></div>
    <img id="meg_an" src="meg_an.png">  
    <div class="menu">
        <h1>Yönetim Paneline Hoş Geldiniz</h1>
        <ul>
        <li><a href="yt_panel1.php"><button >1.Ana Menü</button></a></li>
            <li><a href="yt_panel2.php"><button id="megalodonButton">3.Megaladon-pi Durumu</button></a></li>
            <li><a href="yt_panel3.php"><button>4.Wifi</button></a></li>
            <li><a href="yt_panel4.php"><button>5.Bluetooth</button></a></li>
            <li><a href="yt_panel5.php"><button>6.USB</button></a></li>
            <li><a href="yt_panel6.php"><button>7.Sniff</button></a></li>
            <li><a href="yt_panel7.php"><button id="anamenu">8.Yapımcılar</button></a></li>
            <li><a href="yt_panel9.php"><button>9.Servisler</button></a></li>
            <li><a href="login.php"><button>10.Çıkış</button></a></li>
        </ul>
    </div>
    <div class="kare">
     <h1>AZAT DİCLE</h1>
     <p id="hakkında"> email:azatmg1184@gmail.com <br>
         instagram:azatmurg 
    </p>
    <br>
    <h1>ARDA AYBERK ÇİFCİ</h1>
    <p id="hakkında">
     
    </p>
   </div>
</body>
</html>
