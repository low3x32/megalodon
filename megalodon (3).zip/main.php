<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION["user"];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ana Sayfa</title>
</head>
<body>
    <h2>Hoş Geldiniz, <?php echo $username; ?></h2>
    <a href="logout.php">Çıkış Yap</a>
</body>
</html>
    