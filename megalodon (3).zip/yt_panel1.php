<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Yönetim Paneli</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            background-color: blue;
        }

        h1 {
            text-align: center;
        }

        .menu {
            width: 300px;
            height: 100%;
            position: fixed; /* Menünün sabit bir konumda durmasını sağlar */
            top: 0;
            left: 0;
            background-color: black;
            color: #fff;
            padding: 20px;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        li {
            margin: 10px 0;
        }

        button {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: left;
        }

        button:hover {
            background-color: #2980b9;
        }
        #meg_an {
          display: block; /* Resmi blok öğe yap ve bu, dikey ortalamayı etkinleştirir */
          margin: 0 auto; 
          margin-left: 800px;
        }
        #anamenu{
            background-color: red;
           
        }
        .kare{
    width: 900px; /* Kare genişliği */
    height: 600px; /* Kare yüksekliği */
    background-color: white; /* Kare arka plan rengi */
    margin: 0 auto; /* Kareyi yatayda ortala */
    margin-top: 30px; 
    margin-right: 150px;
        }
    </style>
</head>
<body>
    <?php 
    $id = isset($_GET['id']) ? $_GET['id'] : 0;
    if ($id==1){include("yt_panel1.php");}
    else if($id==2){include("yt_panel2.php");}
    else if($id==3){include("yt_panel3.php");}
    else if($id==4){include("yt_panel4.php");}
    else if($id==5){include("yt_panel5.php");}
    else if($id==6){include("yt_panel6.php");}
    else if($id==7){include("yt_panel7.php");}
    else if($id==8){include("yt_panel8.php");}
    else if($id==9){include("yt_panel9.php");}
    
    
    ?>
    <div id="output"></div>

    <img id="meg_an" src="meg_an.png" >
    <div class="menu">
        <h1>Yönetim Paneline Hoş Geldiniz</h1>
        <ul>
        <li><a href="yt_panel1.php?id=0"><button id="anamenu">1.Ana Menü</button></a></li>
            <li><a href="yt_panel2.php?id=1"><button>3.Megaladon-pi Durumu</button></a></li>
            <li><a href="yt_panel3.php?id=2"><button>4.Wifi</button></a></li>
            <li><a href="yt_panel4.php?id=3"><button>5.Bluetooth</button></a></li>
            <li><a href="yt_panel5.php?id=4"><button>6.USB</button></a></li>
            <li><a href="yt_panel6.php?id=5"><button>7.Sniff</button></a></li>
            <li><a href="yt_panel7.php?id=6"><button>8.Yapımcılar</button></a></li>
            <li><a href="yt_panel9.php?id=7"><button>9.Servisler</button></a></li>
            <li><a href="login.php"><button>10.Çıkış</button></a></li>
        </ul>
    </div>
    <div class="kare">
      
    </div>
</body>
</html>
