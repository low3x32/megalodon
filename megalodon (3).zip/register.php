<?php
session_start();
if (isset($_SESSION["user"])) {
    header("Location: main.php");
    exit;
}

include("config.php");

$errorMessage = ""; // Başlangıçta boş bir hata mesajı

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Kullanıcı adının benzersiz olduğunu kontrol et
    $check_query = "SELECT * FROM users WHERE username = '$username'";
    $check_result = $conn->query($check_query);

    if ($check_result->num_rows > 0) {
        $errorMessage = "Bu kullanıcı adı zaten kullanılıyor. Lütfen başka bir kullanıcı adı seçin.";
    } else {
        // Kullanıcı adı benzersiz, kaydı ekle
        $sql = "INSERT INTO users (username, password) VALUES ('$username', '$password')";
        if ($conn->query($sql) === true) {
            header("Location: login.php");
            exit;
        } else {
            $errorMessage = "Kayıt olma başarısız: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Megalodon-Kayıt Ol</title>
    <link rel="stylesheet" href="style.css" />
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="icon" href="meg1.png" type="image/png">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Popins", sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: url("sea.gif") no-repeat;
            background-size: cover;
            background-position: center;
        }

        .sarıcı {
            width: 420px;
            background: transparent;
            border: 2px solid rgba(255, 255, 255, .2);
            backdrop-filter: blur(20px);
            box-shadow: 0 0 10px rgba(0, 0, 0, .2);
            color: #fff;
            border-radius: 15px;
            padding: 30px 40px;
        }

        .sarıcı h1 {
            font-size: 36px;
            text-align: center;
        }

        .sarıcı .input-box {
            position: relative;
            width: 100%;
            height: 50px;
            margin: 30px 0;
        }

        .input-box input {
            width: 100%;
            height: 100%;
            background: transparent;
            border: none;
            outline: none;
            border: 2px solid white;
            border-radius: 40px;
            font-size: 16px;
            color: white;
            padding: 20px 45px 20px 20px;
        }

        .input-box input::placeholder {
            color: white;
        }

        .input-box i {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
        }

        .sarıcı .unuttum {
            display: flex;
            justify-content: space-between;
            font-size: 14.5px;
            margin: -15px 0 15px;
        }

        .unuttum label input {
            accent-color: white;
            margin-right: 3px;
        }

        .unuttum a {
            color: white;
            text-decoration: none;
        }

        .Parolanızımı unuttunuz a:hover {
            text-decoration: underline;
        }

        .sarıcı .btn {
            width: 100%;
            height: 45px;
            background: white;
            border: none;
            outline: none;
            border-radius: 40px;
            box-shadow: 0 0 3px #000000;
            cursor: pointer;
            font-size: 16px;
            color: #333;
            font-weight: 600;
        }

        .sarıcı .register-link {
            font-size: 14.5px;
            text-align: center;
            margin: 20px 0 15px;
        }

        .register-link p a {
            color: white;
            text-decoration: none;
            font-weight: 600;
        }

        .register-link p a:hover {
            text-decoration: underline;
        }
        .logo {
    text-align: center;
    margin-bottom: 20px;
}

.logo img {
    width: 420px; /* Logo genişliğini ayarlayın */
    padding-right: 40px;
    height: 220px; /* Logo yüksekliğini 420px olarak ayarlayın */
    margin-top: -40px;
    margin-bottom: -40px;
    0px; /* Logo ile yazı arasındaki boşluğu ayarlayın */
}

.logo h1 {
    font-size: 36px;
    color: white;
    text-align: center;
}

        /* Hata mesajı için stil */
        .error-message {
            text-align: center;
        margin-top: 15px;
        padding: 10px; /* Metnin etrafına biraz boşluk ekler */
        
        <?php if (!empty($errorMessage)) { ?>
            animation: shake 0.5s; /* Hata mesajı görüntülendiğinde shake adlı animasyonu kullan */
            background: #FF5757;
            color: #FFF;
            border: 1px solid red;
            border-radius: 5px;
        <?php } else { ?>
            color: transparent; /* Hata yoksa metni şeffaf yapar, böylece görünmez */
            border: none;
        <?php } ?>
        
        }
        @keyframes shake {
        0% { transform: translateX(0); }
        20% { transform: translateX(-5px); }
        40% { transform: translateX(5px); }
        60% { transform: translateX(-5px); }
        80% { transform: translateX(5px); }
        100% { transform: translateX(0); }
    }
    </style>
</head>
<body>
    <div class="sarıcı">
        <form method="post" action="">
        <div class="logo">
            <img src="logo.png" alt="Logo">
            <h1>Kayıt Ol</h1>
            </div>
            <div class="input-box">
                <input type="text" name="username" placeholder="Kullanıcı Adı" required />
                <i class='bx bxs-user'></i>
            </div>
            <div class="input-box">
                <input type="password" name="password" placeholder="Şifre giriniz" required />
                <i class="bx bxs-lock-alt"></i>
            </div>
            <button type="submit" class="btn">Kayıt Ol</button>
            <div class="register-link">
                <p> Zaten bir hesabınız mı var? <a href="login.php">Giriş Yap</a></p>
            </div>

            <!-- Hata mesajı görüntülemek için div ekleniyor -->
            <?php if (!empty($errorMessage)): ?>
                <div class="error-message"><?php echo $errorMessage; ?></div>
            <?php endif; ?>
        </form>
    </div>
</body>
</html>
