<?php
session_start();

if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Yönetim Paneli</title>
</head>
<body>
    <h1>Yönetim Paneli</h1>
    <p>Hoş geldiniz, <?php echo $_SESSION["user"]; ?>!</p>
    <a href="logout.php">Çıkış Yap</a>
</body>
</html>
